/** Automatically generated file. DO NOT MODIFY */
package com.example.aday16_defineview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}