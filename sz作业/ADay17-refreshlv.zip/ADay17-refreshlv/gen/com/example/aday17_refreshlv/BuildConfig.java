/** Automatically generated file. DO NOT MODIFY */
package com.example.aday17_refreshlv;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}