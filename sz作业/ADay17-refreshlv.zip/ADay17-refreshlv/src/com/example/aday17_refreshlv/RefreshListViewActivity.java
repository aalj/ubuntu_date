package com.example.aday17_refreshlv;

import java.util.ArrayList;
import java.util.List;

import com.geminno.entity.Product;
import com.geminno.util.MyBaseAdapter;
import com.geminno.util.ViewHolder;
import com.geminno.view.RefreshListView;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class RefreshListViewActivity extends Activity {

	RefreshListView refreshListView;
	List<Product> products=new ArrayList<Product>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_refresh_list_view);
		//�ҵ�lv
		refreshListView=(RefreshListView) findViewById(R.id.refreshListView1);
		
		initData();
		
		//����adpater
		refreshListView.setAdapter(new MyBaseAdapter<Product>(products,this,R.layout.product_item) {

			@Override
			public void convert(ViewHolder viewHolder, Product item) {
				// TODO Auto-generated method stub
				
				//���ؼ���ֵ
				viewHolder.setText(R.id.textView1, item.getName());
				viewHolder.setText(R.id.textView2, String.valueOf(item.getPrice()));
				
			}
		
		
		
		});
	}
	
	//��ʼ������
	public void initData(){
		Product product1=new Product("��Ʒ1", 31f);
		Product product2=new Product("��Ʒ2", 32f);
		Product product3=new Product("��Ʒ3", 33f);
		Product product4=new Product("��Ʒ4", 34f);
		Product product5=new Product("��Ʒ5", 35f);
		
		
		Product product6=new Product("��Ʒ6", 31f);
		Product product7=new Product("��Ʒ7", 32f);
		Product product8=new Product("��Ʒ8", 33f);
		Product product9=new Product("��Ʒ9", 34f);
		Product product10=new Product("��Ʒ10", 35f);
		
		products.add(product1);
		products.add(product2);
		products.add(product3);
		products.add(product4);
		products.add(product5);
		
		products.add(product6);
		products.add(product7);
		products.add(product8);
		products.add(product9);
		products.add(product10);
				
	}

	
}
