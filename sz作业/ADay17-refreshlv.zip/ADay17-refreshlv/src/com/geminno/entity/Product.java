package com.geminno.entity;

public class Product {

	public Product() {
		// TODO Auto-generated constructor stub
	}
	
	private String name;
	public Product(String name, Float price) {
		super();
		this.name = name;
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}

	private Float price;
	

}
