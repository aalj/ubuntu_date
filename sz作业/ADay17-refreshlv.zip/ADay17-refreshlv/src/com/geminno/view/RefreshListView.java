package com.geminno.view;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.example.aday17_refreshlv.R;

import android.R.integer;
import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.AbsListView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.AbsListView.OnScrollListener;

/*
 * 1������ͷ��
 * 2������ͷ��
 */


public class RefreshListView extends ListView implements OnScrollListener{

	
	View headView;//ͷ��view
	
	ImageView imageView;//��ʾ����
	ProgressBar progressBar;//������
	TextView tvRefreshState;//��ʾ�ı�
	TextView tvRefreshTime;//ˢ��ʱ��
	
	public int headState;//ͷ��״̬��INIT,PREPAREREFERSHER ISREFERING��
	public final int INIT=0;//��ʼ״̬
	public  final int PREPAREREFERSH=1;//׼��ˢ��
	public  final int ISREFERING=2;//����ˢ��
	
	int headHeight;//ͷ���߶�
	int firstVisibleItem;//��һ���ɼ���λ��
	float startY;//��ʼ������Y����
	float moveY;//move��Ӧ�ĵ�Y����
	private RotateAnimation upAnimation;
	private RotateAnimation downAnimation;
	
	public RefreshListView(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		initHead(context);
		initAnimation(context);
		setOnScrollListener(this);
	}

	public RefreshListView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		initHead(context);
		initAnimation(context);
		setOnScrollListener(this);
	}

	public RefreshListView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		// TODO Auto-generated constructor stub
		initHead(context);
		initAnimation(context);
		setOnScrollListener(this);
	}
	
	//��ʼ��ͷ��
	public void initHead(Context context){
		//����xml�ļ�
	     headView=LayoutInflater.from(context).inflate(R.layout.pull_to_refresh_head, null);
		//����ͷ��
		addHeaderView(headView);
		//head�ĸ߶ȡ�
		headView.measure(0, 0);
		headHeight=headView.getMeasuredHeight();
		//����ͷ��
		headView.setPadding(0, -headHeight, 0,0);
		
		//��ʼ��ͷ���ؼ�
		
		  imageView= (ImageView) headView.findViewById(R.id.iv_refresher);
		   progressBar=(ProgressBar) headView.findViewById(R.id.pb_refresher);
		  tvRefreshState=(TextView) headView.findViewById(R.id.tv_refreshertext);
	      tvRefreshTime=(TextView) headView.findViewById(R.id.tv_refreshtime);
		
	}

	@Override
	public boolean onTouchEvent(MotionEvent ev) {
		// TODO Auto-generated method stub
		//down,move,up
		switch (ev.getAction()) {
		case MotionEvent.ACTION_DOWN:
			//��¼��ʼ������
			startY=ev.getY();
			
			break;
        case MotionEvent.ACTION_MOVE:
        	moveY=ev.getY();
			//����ǵ�һ���ɼ�&��������padding���Ÿ�()
        	if(firstVisibleItem==0&&(moveY>startY)){
        		int paddingHeight=(int) (-headHeight+(moveY-startY));
        		
        		//������ľ��롷=headheight;״̬�ı�
        		//��������˲�䣬״̬�ı�
        		if(paddingHeight>=0&&headState==INIT){
        			//״̬�ı�:׼��ˢ��
        			headState=PREPAREREFERSH;
        			//�ı�ؼ��������
        			changeState();
        		}
        		
        		
        		headView.setPadding(0, paddingHeight, 0, 0);
        	}
        	
        	
			break;
       case MotionEvent.ACTION_UP:
			
			break;

		default:
			break;
		}
		
		
		return super.onTouchEvent(ev);
	}

	@Override
	public void onScrollStateChanged(AbsListView view, int scrollState) {
		// TODO Auto-generated method stub
		Log.i("RefreshListView","scrollState:"+scrollState);
		//SCROLL_STATE_FLING;
	}

	@Override
	public void onScroll(AbsListView view, int firstVisibleItem,
			int visibleItemCount, int totalItemCount) {
		// TODO Auto-generated method stub
		Log.i("RefreshListView","onscroll");
		this.firstVisibleItem=firstVisibleItem;
	}
	
	

	public void initAnimation(Context context){
		//0-��180��ѡ�����ĵ���������ԭ��
		upAnimation=new RotateAnimation(0, 180, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
		upAnimation.setFillAfter(true);
		upAnimation.setDuration(100);
		downAnimation=new RotateAnimation(-180, 0, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
		downAnimation.setFillAfter(true);
		downAnimation.setDuration(1000);
	}
	
	
	
	//״̬�ı䣬������ʾ���ݸ����޸�
			public void changeState(){
				switch(headState){
				case INIT:
					progressBar.setVisibility(View.INVISIBLE);
					imageView.setVisibility(View.VISIBLE);
					//��imageView���ö���
					imageView.startAnimation(downAnimation);//���ü�ͷ����
					tvRefreshState.setText("����ˢ��");
					break;
					
				case PREPAREREFERSH:
					progressBar.setVisibility(View.INVISIBLE);
					imageView.setVisibility(View.VISIBLE);
					imageView.startAnimation(upAnimation);////���ü�ͷ����
					tvRefreshState.setText("�ͷ�ˢ��");
					break;
				case ISREFERING:
					progressBar.setVisibility(View.VISIBLE);
					imageView.setVisibility(View.INVISIBLE);
					imageView.clearAnimation();//���imagview�Ķ���
					tvRefreshState.setText("����ˢ��");
					tvRefreshTime.setText(getTime());//ˢ��ʱ��
					break;
				}
				
			}
			
			public String getTime(){
			Calendar calendar=	Calendar.getInstance();
			SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		    String time=	format.format(calendar.getTime());
		    return time;
			}

}
